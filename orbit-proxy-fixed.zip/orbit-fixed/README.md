# 🛸 Orbit Proxy

A Scramjet-powered web proxy. Works on Replit, Railway, Render, VPS, or locally.

---

## ⚠️ Important

`index.html` **must** be served by `server.js` — not a plain static host (no Netlify, GitHub Pages, etc.).  
The proxy depends on `/epoxy/`, `/scram/`, `/baremux/`, and `/wisp/` routes that only the Node server provides.

---

## 🚀 Setup (do this once)

```bash
npm run setup
```

This installs all dependencies including Scramjet (which requires a special install step).

---

## ▶️ Run

```bash
# Production
npm start

# Development (auto-restarts on file changes)
npm run dev
```

Then open **http://localhost:3000**

---

## 🔍 Troubleshooting

**"Proxy error: NetworkError: Load failed — is the server running?"**

This means the browser can't reach `/epoxy/index.mjs`. Check:

1. Did you run `npm run setup` (not just `npm install`)?
2. Are you opening the site via `http://localhost:3000` — served by Node — and not from a separate static server?
3. Open DevTools → Network tab. If `/epoxy/index.mjs`, `/scram/scramjet.all.js`, or `/baremux/index.js` return 404, your page isn't being served by `server.js`.

---

## 🌐 Deployment

| Platform | Command |
|----------|---------|
| Replit   | Set run command to `npm run setup && npm start` |
| Railway  | Set start command to `npm run setup && npm start` |
| Render   | Build: `npm run setup` · Start: `npm start` |
| VPS      | `npm run setup && npm start` (use PM2 for persistence) |

> **Note:** Your host must support Node.js. Static hosts will not work.

---

## Routes

| Path | Purpose |
|------|---------|
| `/scram/` | Scramjet interception engine |
| `/baremux/` | BareMux transport layer |
| `/epoxy/` | Epoxy TCP-over-WebSocket transport |
| `/wisp/` | Wisp WebSocket tunnel (ws://) |
