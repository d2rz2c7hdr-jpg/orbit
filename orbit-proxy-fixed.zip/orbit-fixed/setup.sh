#!/bin/bash
# ═══════════════════════════════════════════════════
#  Orbit Proxy — One-Click Setup Script
#  Run this in your Replit Shell:  bash setup.sh
# ═══════════════════════════════════════════════════

echo ""
echo "  🛸  Orbit Proxy Setup"
echo "  ───────────────────────────────────"

# Check for Node / npm
if ! command -v node &> /dev/null; then
  echo "  ❌ Node.js not found. Install it first: https://nodejs.org"
  exit 1
fi

echo "  ✓  Node $(node -v) found"

# Install pnpm if not available (Replit may already have it)
if ! command -v pnpm &> /dev/null; then
  echo "  Installing pnpm..."
  npm install -g pnpm --silent
fi

echo "  ✓  pnpm ready"
echo ""
echo "  Installing dependencies..."

# Install regular npm deps
pnpm install

echo ""
echo "  Installing Scramjet CI build..."

# Install Scramjet from GitHub CI release (recommended over npm version)
pnpm install https://github.com/MercuryWorkshop/scramjet/releases/download/latest/mercuryworkshop-scramjet-1.0.2-dev.tgz

echo ""
echo "  ✅  All dependencies installed!"
echo ""
echo "  ─── Start the server ─────────────────"
echo "  node server.js"
echo ""
echo "  Your site will be live at the URL"
echo "  Replit shows at the top of the screen."
echo "  ──────────────────────────────────────"
echo ""
