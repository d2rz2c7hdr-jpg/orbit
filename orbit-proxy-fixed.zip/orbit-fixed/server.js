// ═══════════════════════════════════════════════
//  Orbit Proxy — server.js
//  Works on Replit, Railway, Render, VPS, etc.
// ═══════════════════════════════════════════════
import express from "express";
import { createServer } from "http";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import { createRequire } from "module";

const require = createRequire(import.meta.url);
const __dirname = dirname(fileURLToPath(import.meta.url));

const app = express();
const server = createServer(app);

// ── Scramjet static files ──────────────────────
// Served at /scram/ so sw.js can importScripts("/scram/scramjet.all.js")
import { scramjetPath } from "@mercuryworkshop/scramjet/path";
// ^ If this throws, run: npm run setup
app.use("/scram/", express.static(scramjetPath));

// ── BareMux static files ───────────────────────
import { baremuxPath } from "@mercuryworkshop/bare-mux/node";
app.use("/baremux/", express.static(baremuxPath));

// ── EpoxyTransport static files ────────────────
import { epoxyPath } from "@mercuryworkshop/epoxy-transport";
app.use("/epoxy/", express.static(epoxyPath));

// ── Serve all site files ───────────────────────
app.use(express.static(join(__dirname, "public")));

// ── Wisp WebSocket server ──────────────────────
// Wisp is used by Epoxy to tunnel TCP connections through WebSockets.
// It listens at /wisp/ on the same port as the HTTP server.
import { WispServer } from "wisp-server-node";
const wisp = new WispServer();
server.on("upgrade", (req, socket, head) => {
  if (req.url.startsWith("/wisp/")) {
    wisp.handleUpgrade(req, socket, head);
  }
});

// ── Catch-all: serve index.html ────────────────
app.get("*", (_req, res) => {
  res.sendFile(join(__dirname, "public", "index.html"));
});

// ── Start ──────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n  🛸  Orbit running at http://localhost:${PORT}`);
  console.log(`  Scramjet  → /scram/`);
  console.log(`  BareMux   → /baremux/`);
  console.log(`  Epoxy     → /epoxy/`);
  console.log(`  Wisp WS   → ws://localhost:${PORT}/wisp/\n`);
});
